#!/usr/bin/env python

DEBUG = False
DISABLE_RESIZE_SYSTEM = False